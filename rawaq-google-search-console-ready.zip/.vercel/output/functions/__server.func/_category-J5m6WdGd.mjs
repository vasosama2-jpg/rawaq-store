import { i as categoryLabel } from "./_ssr/shop-DYw5t3xI.mjs";
import { x as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./_ssr/router-DvrpmqTW.mjs";
import { t as Shell } from "./_ssr/shell-MUgdo7ZH.mjs";
import { t as ProductCard } from "./_ssr/product-card-Bvz8C15l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_category-J5m6WdGd.js
var import_jsx_runtime = require_jsx_runtime();
function SectionPage() {
	const { shop, category, products } = Route.useLoaderData();
	const label = categoryLabel(category);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		shop,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-8 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "underline-offset-4 hover:underline",
						children: "الأقسام"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: products.length === 0 ? "لسا ما في أغراض بهالقسم." : `${products.length} أغراض`
				}),
				products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/manage",
						className: "text-primary underline-offset-4 hover:underline",
						children: "ضيف أول غرض من الإدارة"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-3",
					children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "min-w-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
							product,
							currency: shop.currency
						})
					}, product.id))
				})
			]
		})
	});
}
//#endregion
export { SectionPage as component };
