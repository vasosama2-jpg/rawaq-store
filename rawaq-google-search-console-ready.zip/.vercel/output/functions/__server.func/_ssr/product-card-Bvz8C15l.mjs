import { o as __toESM } from "../_runtime.mjs";
import { a as formatPrice, i as categoryLabel } from "./shop-DYw5t3xI.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-Bvz8C15l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product, currency, featured = false }) {
	const [broken, setBroken] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/product/$productId",
		params: { productId: String(product.id) },
		className: featured ? "group grid items-center gap-6 lg:grid-cols-2" : "group block min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-2xl bg-surface",
			children: product.image && !broken ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: product.image,
				alt: product.title,
				className: "aspect-product w-full object-cover transition-transform duration-300 ease-out group-hover:scale-105",
				onError: () => setBroken(true)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex aspect-product items-center justify-center font-display text-5xl text-muted",
				children: product.title.slice(0, 1)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: featured ? "space-y-3" : "mt-3 space-y-1",
			children: [
				featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "على الرف الأول"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: featured ? "font-display text-4xl" : "font-display text-2xl leading-tight",
					children: product.title
				}),
				featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-muted",
					children: product.summary
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tabular-nums text-primary",
					children: formatPrice(product.price, currency)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						categoryLabel(product.category),
						product.origin ? ` · ${product.origin}` : "",
						!product.available ? " · خلصت" : ""
					]
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
