//#region node_modules/.nitro/vite/services/ssr/assets/shop-DYw5t3xI.js
var CURRENCY_IDS = [
	"USD",
	"SYP",
	"JOD",
	"LBP",
	"TRY",
	"AED",
	"SAR",
	"EUR"
];
var CURRENCIES = [
	{
		id: "USD",
		label: "دولار"
	},
	{
		id: "SYP",
		label: "ليرة سورية"
	},
	{
		id: "JOD",
		label: "دينار أردني"
	},
	{
		id: "LBP",
		label: "ليرة لبنانية"
	},
	{
		id: "TRY",
		label: "ليرة تركية"
	},
	{
		id: "AED",
		label: "درهم"
	},
	{
		id: "SAR",
		label: "ريال"
	},
	{
		id: "EUR",
		label: "يورو"
	}
];
var CATEGORIES = [
	{
		id: "bags",
		label: "الشناتي"
	},
	{
		id: "shoes",
		label: "الأحذية"
	},
	{
		id: "wear",
		label: "لباس"
	},
	{
		id: "food",
		label: "مونة وطعام"
	},
	{
		id: "textile",
		label: "نسيج وبيت"
	},
	{
		id: "brass",
		label: "نحاس وحرف"
	},
	{
		id: "care",
		label: "عناية"
	}
];
var CATEGORY_LABELS = Object.fromEntries(CATEGORIES.map((category) => [category.id, category.label]));
function categoryLabel(id) {
	return CATEGORY_LABELS[id] ?? id;
}
function formatPrice(amount, currency) {
	const n = new Intl.NumberFormat("ar-u-nu-latn").format(amount);
	switch (currency) {
		case "USD": return `$${n}`;
		case "EUR": return `€${n}`;
		case "TRY": return `${n} ₺`;
		case "SYP": return `${n} ل.س`;
		case "JOD": return `${n} د.أ`;
		case "LBP": return `${n} ل.ل`;
		case "AED": return `${n} د.إ`;
		case "SAR": return `${n} ر.س`;
		default: return `${n} ${currency}`;
	}
}
function orderMessage(shopName, currency, lines) {
	const rows = lines.map((line) => `• ${line.title} × ${line.qty} — ${formatPrice(line.price * line.qty, currency)}`);
	const total = lines.reduce((sum, line) => sum + line.price * line.qty, 0);
	return `مرحبا ${shopName}\nحابب أطلب:\n${rows.join("\n")}\nالمجموع: ${formatPrice(total, currency)}`;
}
function whatsappLink(phone, text) {
	const digits = phone.replace(/\D/g, "");
	if (!digits) return "";
	return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}
//#endregion
export { formatPrice as a, categoryLabel as i, CURRENCIES as n, orderMessage as o, CURRENCY_IDS as r, whatsappLink as s, CATEGORIES as t };
