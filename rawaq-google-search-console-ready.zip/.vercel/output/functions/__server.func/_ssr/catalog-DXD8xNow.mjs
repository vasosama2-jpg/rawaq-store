import { r as CURRENCY_IDS } from "./shop-DYw5t3xI.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DXD8xNow.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var keySchema = object({ key: string().trim().min(4, "كلمة السر أربع خانات على الأقل").max(80, "كلمة السر طويلة") });
var shopSchema = keySchema.extend({
	name: string().trim().min(2, "اسم المحل قصير").max(40, "اسم المحل طويل"),
	tagline: string().trim().min(2, "السطر التعريفي قصير").max(120, "السطر التعريفي طويل"),
	about: string().trim().max(600, "النبذة طويلة"),
	city: string().trim().max(40, "اسم المدينة طويل"),
	whatsapp: string().trim().max(24, "الرقم طويل"),
	currency: _enum(CURRENCY_IDS)
});
var productSchema = keySchema.extend({
	id: number().int().positive().optional(),
	title: string().trim().min(2, "اسم القطعة قصير").max(80, "اسم القطعة طويل"),
	summary: string().trim().min(2, "الوصف القصير ناقص").max(180, "الوصف القصير طويل"),
	story: string().trim().max(2e3, "التفاصيل طويلة"),
	price: number().int("السعر رقم صحيح").min(0, "السعر ما بينقص عن صفر").max(1e8, "السعر كبير"),
	category: string().trim().min(1, "اختار تصنيف").max(40, "التصنيف طويل"),
	origin: string().trim().max(80, "المصدر طويل"),
	available: boolean(),
	featured: boolean(),
	imageData: string().max(12e5, "الصورة كبيرة")
});
var idSchema = object({ id: number().int().positive() });
var deleteSchema = keySchema.extend({ id: idSchema.shape.id });
function parse(schema, input) {
	const parsed = schema.safeParse(input);
	if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? "البيانات ناقصة");
	return parsed.data;
}
var fetchCatalog_createServerFn_handler = createServerRpc({
	id: "e969a9bcdcbcbe969700beabbdacece16fd01404a248e7c0b489d037e59d1f72",
	name: "fetchCatalog",
	filename: "src/lib/catalog.ts"
}, (opts) => fetchCatalog.__executeServer(opts));
var fetchCatalog = createServerFn({ method: "GET" }).handler(fetchCatalog_createServerFn_handler, async () => {
	const { readCatalog } = await import("./catalog.server-CfrolxO1.mjs");
	return readCatalog();
});
var fetchProduct_createServerFn_handler = createServerRpc({
	id: "761baa44c03c8849cde33d671e346f8165aaa85f8443753097b3f249163c73f6",
	name: "fetchProduct",
	filename: "src/lib/catalog.ts"
}, (opts) => fetchProduct.__executeServer(opts));
var fetchProduct = createServerFn({ method: "GET" }).validator((input) => parse(idSchema, input)).handler(fetchProduct_createServerFn_handler, async ({ data }) => {
	const { readProduct } = await import("./catalog.server-CfrolxO1.mjs");
	return readProduct(data.id);
});
var setManageKey_createServerFn_handler = createServerRpc({
	id: "dec929b1ab42e2ef1424447575642b628a0b5d5b612bf0dc7b61db87ab9974a2",
	name: "setManageKey",
	filename: "src/lib/catalog.ts"
}, (opts) => setManageKey.__executeServer(opts));
var setManageKey = createServerFn({ method: "POST" }).validator((input) => parse(keySchema, input)).handler(setManageKey_createServerFn_handler, async ({ data }) => {
	const { setShopKey } = await import("./catalog.server-CfrolxO1.mjs");
	return setShopKey(data.key);
});
var checkManageKey_createServerFn_handler = createServerRpc({
	id: "95f8ae7a211ed182414e5f334a9af9ad21c4864b94e0b95359e292e6f7c3e883",
	name: "checkManageKey",
	filename: "src/lib/catalog.ts"
}, (opts) => checkManageKey.__executeServer(opts));
var checkManageKey = createServerFn({ method: "POST" }).validator((input) => parse(keySchema, input)).handler(checkManageKey_createServerFn_handler, async ({ data }) => {
	const { checkShopKey } = await import("./catalog.server-CfrolxO1.mjs");
	return checkShopKey(data.key);
});
var updateShop_createServerFn_handler = createServerRpc({
	id: "ac4d0c9ca2c763c74cb1cbfa67c8cab2e694c092aa9b06f87ef5ee7fceb7ba89",
	name: "updateShop",
	filename: "src/lib/catalog.ts"
}, (opts) => updateShop.__executeServer(opts));
var updateShop = createServerFn({ method: "POST" }).validator((input) => parse(shopSchema, input)).handler(updateShop_createServerFn_handler, async ({ data }) => {
	const { saveShop } = await import("./catalog.server-CfrolxO1.mjs");
	return saveShop(data);
});
var updateProduct_createServerFn_handler = createServerRpc({
	id: "002832a975c273ddcc70d67e9c2c417c9f8eba5dc917f527511d1b21c5108a7a",
	name: "updateProduct",
	filename: "src/lib/catalog.ts"
}, (opts) => updateProduct.__executeServer(opts));
var updateProduct = createServerFn({ method: "POST" }).validator((input) => parse(productSchema, input)).handler(updateProduct_createServerFn_handler, async ({ data }) => {
	const { saveProduct } = await import("./catalog.server-CfrolxO1.mjs");
	return saveProduct(data);
});
var deleteProduct_createServerFn_handler = createServerRpc({
	id: "2ee09114606aaec50f620f4ba56b5ae21103647c2dad5c041a85f2d75052e35b",
	name: "deleteProduct",
	filename: "src/lib/catalog.ts"
}, (opts) => deleteProduct.__executeServer(opts));
var deleteProduct = createServerFn({ method: "POST" }).validator((input) => parse(deleteSchema, input)).handler(deleteProduct_createServerFn_handler, async ({ data }) => {
	const { removeProduct } = await import("./catalog.server-CfrolxO1.mjs");
	return removeProduct(data.id, data.key);
});
//#endregion
export { checkManageKey_createServerFn_handler, deleteProduct_createServerFn_handler, fetchCatalog_createServerFn_handler, fetchProduct_createServerFn_handler, setManageKey_createServerFn_handler, updateProduct_createServerFn_handler, updateShop_createServerFn_handler };
