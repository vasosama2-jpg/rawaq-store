import { o as __toESM } from "../_runtime.mjs";
import { i as categoryLabel, t as CATEGORIES } from "./shop-DYw5t3xI.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$4 } from "./router-DvrpmqTW.mjs";
import { t as Shell } from "./shell-MUgdo7ZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BhjnveAJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { shop, products } = Route$4.useLoaderData();
	const [broken, setBroken] = (0, import_react.useState)({});
	const sections = (0, import_react.useMemo)(() => {
		const counts = /* @__PURE__ */ new Map();
		const thumbs = /* @__PURE__ */ new Map();
		for (const product of products) {
			counts.set(product.category, (counts.get(product.category) ?? 0) + 1);
			if (!thumbs.has(product.category) && product.image) thumbs.set(product.category, product.image);
		}
		const known = CATEGORIES.map((item) => item.id);
		const extra = [...counts.keys()].filter((id) => !known.includes(id));
		return [...known, ...extra].map((id) => ({
			id,
			label: categoryLabel(id),
			count: counts.get(id) ?? 0,
			image: thumbs.get(id) ?? ""
		})).filter((section) => section.count > 0);
	}, [products]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		shop,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-3xl px-4 pb-8 pt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl",
					children: shop.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "اختار قسم. جوا بتلاقي الأغراض، ومن الإدارة بتعدّل."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2",
					children: sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/section/$category",
						params: { category: section.id },
						className: "flex min-h-24 items-center gap-4 rounded-2xl border border-line bg-surface p-3 transition-transform duration-150 ease-out active:scale-[0.96]",
						children: [section.image && !broken[section.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: section.image,
							alt: "",
							className: "aspect-product w-16 rounded-xl object-cover",
							onError: () => setBroken((current) => ({
								...current,
								[section.id]: true
							}))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex aspect-product w-16 items-center justify-center rounded-xl bg-bg font-display text-2xl text-muted",
							children: section.label.slice(0, 1)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-3xl leading-tight",
								children: section.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: section.count === 0 ? "فاضي" : `${section.count} أغراض`
							})]
						})]
					}) }, section.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-8 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/manage",
						className: "text-ink underline-offset-4 hover:underline",
						children: "إدارة المحل"
					}), " — غيّر الاسم، ضيف غرض، أو انقله لقسم ثاني."]
				})
			]
		})
	});
}
//#endregion
export { Home as component };
