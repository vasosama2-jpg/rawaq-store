import { o as __toESM } from "../_runtime.mjs";
import { a as formatPrice, o as orderMessage, s as whatsappLink } from "./shop-DYw5t3xI.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Minus, i as Plus, r as ShoppingBag, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-MUgdo7ZH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "riwaq-cart";
var EMPTY = [];
var snapshot = EMPTY;
var listeners = /* @__PURE__ */ new Set();
var hydrated = false;
function emit() {
	listeners.forEach((listener) => listener());
}
function persist() {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
	emit();
}
function isLine(value) {
	if (!value || typeof value !== "object") return false;
	const line = value;
	return typeof line.id === "number" && typeof line.title === "string" && typeof line.price === "number" && typeof line.image === "string" && typeof line.qty === "number";
}
function subscribe(listener) {
	listeners.add(listener);
	return () => listeners.delete(listener);
}
function getSnapshot() {
	return snapshot;
}
function useCart() {
	const lines = (0, import_react.useSyncExternalStore)(subscribe, getSnapshot, () => EMPTY);
	(0, import_react.useEffect)(() => {
		if (hydrated) return;
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			const parsed = raw ? JSON.parse(raw) : [];
			snapshot = Array.isArray(parsed) ? parsed.filter(isLine) : EMPTY;
		} catch {
			snapshot = EMPTY;
		}
		hydrated = true;
		emit();
	}, []);
	return lines;
}
function addToCart(line) {
	snapshot = snapshot.find((item) => item.id === line.id) ? snapshot.map((item) => item.id === line.id ? {
		...line,
		qty: Math.min(99, item.qty + 1)
	} : item) : [...snapshot, {
		...line,
		qty: 1
	}];
	persist();
}
function setCartQty(id, qty) {
	snapshot = qty <= 0 ? snapshot.filter((item) => item.id !== id) : snapshot.map((item) => item.id === id ? {
		...item,
		qty: Math.min(99, qty)
	} : item);
	persist();
}
function clearCart() {
	snapshot = EMPTY;
	persist();
}
function cartCount(lines) {
	return lines.reduce((sum, line) => sum + line.qty, 0);
}
function Shell({ shop, children }) {
	const lines = useCart();
	const count = cartCount(lines);
	const [open, setOpen] = (0, import_react.useState)(false);
	const titleId = (0, import_react.useId)();
	const total = lines.reduce((sum, line) => sum + line.price * line.qty, 0);
	const message = orderMessage(shop.name, shop.currency, lines);
	const wa = whatsappLink(shop.whatsapp, message);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			window.removeEventListener("keydown", onKey);
		};
	}, [open]);
	async function copyOrder() {
		try {
			await navigator.clipboard.writeText(message);
			setCopied(true);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:bg-surface focus:px-3 focus:py-2",
				children: "تخطى للمحتوى"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "min-h-11 leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-3xl",
							children: shop.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: shop.city || "معرض مفتوح"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "ms-auto flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "inline-flex min-h-11 items-center rounded-full px-3 text-sm text-ink",
								children: "الأقسام"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/manage",
								className: "inline-flex min-h-11 items-center rounded-full px-3 text-sm text-ink",
								children: "إدارة المحل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpen(true),
								className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 text-sm transition-transform duration-150 ease-out active:scale-[0.96]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									"الطلب",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums text-primary",
										children: count
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "content",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto mt-20 max-w-6xl border-t border-line px-4 py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: shop.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-muted",
						children: shop.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: "المعرض عام. أي حدا يفتح الرابط يشوف نفس البضاعة، ويقدر يجهّز طلب ويرسله للمحل."
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-ink/40",
					"aria-label": "إغلاق الطلب",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": titleId,
					className: "absolute inset-y-0 end-0 flex w-full max-w-md flex-col bg-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: titleId,
								className: "font-display text-3xl",
								children: "الطلب"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								autoFocus: true,
								onClick: () => setOpen(false),
								className: "inline-flex size-11 items-center justify-center rounded-full",
								"aria-label": "إغلاق",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 overflow-y-auto px-4 py-4",
							children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "الطلب فاضي. اختار قطعة من المعرض."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-4",
								children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [line.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: line.image,
										alt: "",
										className: "aspect-product w-16 rounded-xl object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-product w-16 rounded-xl bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-xl leading-tight",
												children: line.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "tabular-nums text-sm text-primary",
												children: formatPrice(line.price, shop.currency)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
														"aria-label": "نقص الكمية",
														onClick: () => setCartQty(line.id, line.qty - 1),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-6 text-center tabular-nums",
														children: line.qty
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
														"aria-label": "زيد الكمية",
														onClick: () => setCartQty(line.id, line.qty + 1),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
													})
												]
											})
										]
									})]
								}, line.id))
							})
						}),
						lines.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-line px-4 py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 flex items-baseline justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "المجموع"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-3xl tabular-nums text-primary",
										children: formatPrice(total, shop.currency)
									})]
								}),
								wa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: wa,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex min-h-11 w-full items-center justify-center rounded-full bg-primary px-5 text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96]",
									children: "أرسل الطلب على واتساب"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => void copyOrder(),
									className: "inline-flex min-h-11 w-full items-center justify-center rounded-full bg-primary px-5 text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96]",
									children: copied ? "اننسخ الطلب" : "انسخ نص الطلب"
								}),
								!shop.whatsapp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: "حط رقم واتساب من إدارة المحل حتى يوصل الطلب برسالة جاهزة."
								}) : null
							]
						}) : null
					]
				})]
			}) : null
		]
	});
}
//#endregion
export { useCart as i, addToCart as n, clearCart as r, Shell as t };
