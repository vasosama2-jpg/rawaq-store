import { r as CURRENCY_IDS } from "./shop-DYw5t3xI.mjs";
import { createHash, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog.server-CfrolxO1.js
var _0002_catalog_default = "-- Public goods catalog. Rows are unowned: anyone can read them.\n-- Writes require the shop key checked in server functions (not a user account).\n\ncreate table if not exists shop (\n  id integer primary key check (id = 1),\n  name text not null,\n  tagline text not null,\n  about text not null,\n  city text not null default '',\n  whatsapp text not null default '',\n  currency text not null default 'USD',\n  key_hash text,\n  updated_at timestamptz not null default now()\n);\n\ninsert into shop (id, name, tagline, about, city, currency)\nvalues (\n  1,\n  'رِواق',\n  'بضاعتك معروضة، والباب مفتوح للكل',\n  'رواق رف واحد لبضاعة مختارة: زيت، نسيج، نحاس، وعناية البيت. اللي يفتح الصفحة، من أي جهاز، يشوف نفس المعرض.',\n  '',\n  'USD'\n)\non conflict (id) do nothing;\n\ncreate table if not exists products (\n  id serial primary key,\n  title text not null,\n  summary text not null,\n  story text not null,\n  price integer not null check (price >= 0 and price <= 100000000),\n  category text not null,\n  origin text not null default '',\n  image_path text,\n  image_data text,\n  available boolean not null default true,\n  featured boolean not null default false,\n  sort_order integer not null default 0,\n  created_at timestamptz not null default now()\n);\n\ninsert into products (title, summary, story, price, category, origin, image_path, featured, sort_order)\nvalues\n  (\n    'زيت زيتون بكر',\n    'عصر على البارد، بعبوة زجاج غامق.',\n    'زيت ثقيل ولونه ذهبي، ريحة عشب أخضر أول ما تنفتح العبوة. ينفع للمائدة وللطبخ الخفيف. العبوة ٤٠٠ مل.',\n    18,\n    'food',\n    'الموسم الحالي',\n    '/products/olive.jpg',\n    true,\n    1\n  ),\n  (\n    'كليم يدوي',\n    'نسيج هندسي بألوان التراب والقمح.',\n    'قطعة أرضية صغيرة من الصوف، نقوش متكسرة. تتفرش جنب الكنبة أو تتعلّق على الحيط. القياس حوالي ١٤٠ في ٩٠.',\n    145,\n    'textile',\n    'نول يدوي',\n    '/products/kilim.jpg',\n    true,\n    2\n  ),\n  (\n    'دلة قهوة',\n    'نحاس بمقبض خشب، لثلاث فناجين.',\n    'دلة للمزاج الصباحي. تتسع لثلاث فناجين وتتحط على نار هادية. امسحيها بقطعة ناشفة بعد كل استعمال.',\n    62,\n    'brass',\n    'نحاس',\n    '/products/dallah.jpg',\n    false,\n    3\n  ),\n  (\n    'صابون غار',\n    'ثلاث قوالب زيتون وغار، من غير عطر صناعي.',\n    'صابون بيت من زيت الزيتون والغار. ينفع للوجه والجسم، وريحته خفيفة. العلبة فيها ثلاث قوالب.',\n    11,\n    'care',\n    'زيتون وغار',\n    '/products/soap.jpg',\n    false,\n    4\n  ),\n  (\n    'صندل جلد',\n    'نعل مسطّح وحزام واحد، بلون القمح.',\n    'جلد طبيعي، مريح للمشي اليومي. المقاس ينذكر برسالة الطلب حتى نأكد التوفر.',\n    46,\n    'wear',\n    'جلد',\n    '/products/sandals.jpg',\n    false,\n    5\n  ),\n  (\n    'قنديل موزاييك',\n    'زجاج ملون يرمى نور دافي على الحيط.',\n    'قنديل صغير للطاولة. الزجاج يكسّر النور: أحمر وعسلي وأخضر. المصباح مشمول.',\n    88,\n    'brass',\n    'زجاج ملون',\n    '/products/lamp.jpg',\n    true,\n    6\n  ),\n  (\n    'بهارات المائدة',\n    'سماق وزعتر وفلفل بعلب نحاس.',\n    'ثلاث علب بغطا: سماق، زعتر بسمسم، وفلفل أحمر. من غير مواد حافظة.',\n    24,\n    'food',\n    'خلطة البيت',\n    '/products/spices.jpg',\n    false,\n    7\n  ),\n  (\n    'مخدة تطريز',\n    'قطن مطرّز بإبرة، والحشوة مشمولة.',\n    'نقشة نباتية بخيط أحمر باهت. القياس ٤٥ في ٤٥. تنغسل على البارد.',\n    34,\n    'textile',\n    'تطريز يدوي',\n    '/products/cushion.jpg',\n    false,\n    8\n  ),\n  (\n    'عسل جبلي',\n    'عسل خام كثيف، مع عود خشب.',\n    'عسل من موسم الربيع، قوامه كثيف وطعمه زهري. البرطمان ٣٥٠ غرام. يتحفظ بعيد عن الشمس.',\n    16,\n    'food',\n    'موسم الربيع',\n    '/products/honey.jpg',\n    false,\n    9\n  );\n";
var _0003_sections_default = "-- Sections the shop owner asked for: bags and shoes, editable like the rest.\n\nupdate products\nset category = 'shoes'\nwhere title = 'صندل جلد' and category = 'wear';\n\ninsert into products (title, summary, story, price, category, origin, image_path, featured, sort_order)\nselect\n  'شنتة جلد',\n  'شنتة يومية بمقبضين، من غير نقش.',\n  'جلد بلون ترابي، تتسع للمحفظة والجوال. المقاس متوسط.',\n  54,\n  'bags',\n  'جلد',\n  '/products/bag.jpg',\n  false,\n  1\nwhere not exists (select 1 from products where title = 'شنتة جلد');\n\ninsert into products (title, summary, story, price, category, origin, image_path, featured, sort_order)\nselect\n  'حذاء رياضي',\n  'قماش أسود ونعل فاتح، للمشي اليومي.',\n  'خفيف ومن غير شعار. المقاس ينذكر برسالة الطلب.',\n  39,\n  'shoes',\n  'رياضي',\n  '/products/sneakers.jpg',\n  false,\n  2\nwhere not exists (select 1 from products where title = 'حذاء رياضي');\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({
			"/migrations/0002_catalog.sql": _0002_catalog_default,
			"/migrations/0003_sections.sql": _0003_sections_default
		});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var MAX_PRODUCTS = 200;
var IMAGE_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
var ShopError = class extends Error {};
function flag(value) {
	return value === true || value === "t" || value === "true" || value === 1;
}
function hashKey(key) {
	return createHash("sha256").update(`riwaq-v1|${key}`).digest("hex");
}
function hashEquals(stored, key) {
	const a = Buffer.from(stored);
	const b = Buffer.from(hashKey(key));
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
function normalizePhone(raw) {
	const digits = raw.replace(/\D/g, "");
	if (!digits) return "";
	if (digits.length < 8 || digits.length > 15) throw new ShopError("اكتب رقم الواتساب مع رمز البلد، من غير صفر بالأول");
	return digits;
}
function mapShop(row) {
	return {
		name: row.name,
		tagline: row.tagline,
		about: row.about,
		city: row.city,
		whatsapp: row.whatsapp,
		currency: row.currency,
		hasKey: flag(row.has_key)
	};
}
function mapProduct(row) {
	const path = row.image_path?.trim() ? row.image_path : "";
	return {
		id: Number(row.id),
		title: row.title,
		summary: row.summary,
		story: row.story,
		price: Number(row.price),
		category: row.category,
		origin: row.origin ?? "",
		image: path || (flag(row.has_upload) ? `/media/${Number(row.id)}` : ""),
		available: flag(row.available),
		featured: flag(row.featured)
	};
}
async function db() {
	return getSql();
}
async function ensureShop(sql) {
	await sql`
    insert into shop (id, name, tagline, about, city, currency)
    values (
      1,
      'رِواق',
      'بضاعتك معروضة، والباب مفتوح للكل',
      'رواق رف واحد لبضاعة مختارة. اللي يفتح الصفحة يشوف نفس المعرض.',
      '',
      'USD'
    )
    on conflict (id) do nothing
  `;
}
async function readShop(sql) {
	await ensureShop(sql);
	const row = (await sql`
    select name, tagline, about, city, whatsapp, currency,
           (key_hash is not null) as has_key
    from shop where id = 1
  `)[0];
	if (!row) throw new ShopError("تعريف المحل مش موجود");
	return mapShop(row);
}
async function requireKey(sql, key) {
	const hash = (await sql`select key_hash from shop where id = 1`)[0]?.key_hash;
	if (!hash) return "فعّل كلمة سر المحل أولاً";
	if (!hashEquals(hash, key)) return "كلمة السر غلط";
	return null;
}
function fail(error) {
	if (error instanceof ShopError) return {
		ok: false,
		error: error.message
	};
	console.error(error);
	return {
		ok: false,
		error: "ما قدرنا نحفظ. جرّب مرة ثانية."
	};
}
async function readCatalog() {
	const sql = await db();
	return {
		shop: await readShop(sql),
		products: (await sql`
    select id, title, summary, story, price, category, origin, image_path,
           (image_data is not null) as has_upload, available, featured
    from products
    order by featured desc, sort_order asc, id asc
  `).map(mapProduct)
	};
}
async function readProduct(id) {
	const sql = await db();
	const shop = await readShop(sql);
	const row = (await sql`
    select id, title, summary, story, price, category, origin, image_path,
           (image_data is not null) as has_upload, available, featured
    from products
    where id = ${id}
  `)[0];
	if (!row) return null;
	const product = mapProduct(row);
	return {
		shop,
		product,
		related: (await sql`
    select id, title, summary, story, price, category, origin, image_path,
           (image_data is not null) as has_upload, available, featured
    from products
    where id <> ${id}
    order by (category = ${product.category}) desc, featured desc, sort_order asc, id asc
    limit 3
  `).map(mapProduct)
	};
}
async function readImage(id) {
	const row = (await (await db())`
    select image_data, image_path from products where id = ${id}
  `)[0];
	if (!row) return null;
	if (row.image_data) {
		const match = IMAGE_RE.exec(row.image_data);
		if (!match) return null;
		const type = `image/${match[1] ?? "jpeg"}`;
		const b64 = row.image_data.slice(row.image_data.indexOf(",") + 1);
		return {
			kind: "bytes",
			type,
			bytes: Buffer.from(b64, "base64")
		};
	}
	if (row.image_path) return {
		kind: "path",
		path: row.image_path
	};
	return null;
}
async function setShopKey(key) {
	try {
		const sql = await db();
		await ensureShop(sql);
		if (!(await sql`
      update shop
      set key_hash = ${hashKey(key)}, updated_at = now()
      where id = 1 and key_hash is null
      returning id
    `)[0]) return {
			ok: false,
			error: "انحطت كلمة سر قبل هلق."
		};
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
}
async function checkShopKey(key) {
	try {
		const sql = await db();
		await ensureShop(sql);
		const problem = await requireKey(sql, key);
		if (problem) return {
			ok: false,
			error: problem
		};
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
}
async function saveShop(input) {
	try {
		const sql = await db();
		await ensureShop(sql);
		const problem = await requireKey(sql, input.key);
		if (problem) return {
			ok: false,
			error: problem
		};
		if (!CURRENCY_IDS.includes(input.currency)) throw new ShopError("العملة مش مدعومة");
		const phone = normalizePhone(input.whatsapp);
		await sql`
      update shop set
        name = ${input.name},
        tagline = ${input.tagline},
        about = ${input.about},
        city = ${input.city},
        whatsapp = ${phone},
        currency = ${input.currency},
        updated_at = now()
      where id = 1
    `;
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
}
async function saveProduct(input) {
	try {
		const sql = await db();
		await ensureShop(sql);
		const problem = await requireKey(sql, input.key);
		if (problem) return {
			ok: false,
			error: problem
		};
		const image = input.imageData.trim();
		if (image && !IMAGE_RE.test(image)) throw new ShopError("الصورة ما انقبلت. جرّب JPG.");
		if (input.id) {
			if (!(await sql`select id from products where id = ${input.id}`)[0]) return {
				ok: false,
				error: "القطعة مش موجودة"
			};
			if (image) await sql`
          update products set
            title = ${input.title},
            summary = ${input.summary},
            story = ${input.story},
            price = ${input.price},
            category = ${input.category},
            origin = ${input.origin},
            available = ${input.available},
            featured = ${input.featured},
            image_data = ${image},
            image_path = null
          where id = ${input.id}
        `;
			else await sql`
          update products set
            title = ${input.title},
            summary = ${input.summary},
            story = ${input.story},
            price = ${input.price},
            category = ${input.category},
            origin = ${input.origin},
            available = ${input.available},
            featured = ${input.featured}
          where id = ${input.id}
        `;
			return { ok: true };
		}
		if (!image) throw new ShopError("حط صورة للقطعة");
		const counts = await sql`select count(*)::int as n from products`;
		if (Number(counts[0]?.n ?? 0) >= MAX_PRODUCTS) throw new ShopError("المعرض امتلأ. احذف قطعة قبل ما تضيف.");
		await sql`
      insert into products (
        title, summary, story, price, category, origin,
        image_path, image_data, available, featured, sort_order
      ) values (
        ${input.title}, ${input.summary}, ${input.story}, ${input.price},
        ${input.category}, ${input.origin}, null, ${image},
        ${input.available}, ${input.featured}, 0
      )
    `;
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
}
async function removeProduct(id, key) {
	try {
		const sql = await db();
		await ensureShop(sql);
		const problem = await requireKey(sql, key);
		if (problem) return {
			ok: false,
			error: problem
		};
		if (!(await sql`
      delete from products where id = ${id} returning id
    `)[0]) return {
			ok: false,
			error: "القطعة مش موجودة"
		};
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
}
//#endregion
export { checkShopKey, readCatalog, readImage, readProduct, removeProduct, saveProduct, saveShop, setShopKey };
