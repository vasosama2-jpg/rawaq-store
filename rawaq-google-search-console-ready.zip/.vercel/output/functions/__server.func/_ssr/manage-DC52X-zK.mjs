import { o as __toESM } from "../_runtime.mjs";
import { a as formatPrice, i as categoryLabel, n as CURRENCIES, t as CATEGORIES } from "./shop-DYw5t3xI.mjs";
import { Y as require_react, b as useRouter, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as setManageKey, i as Route$3, l as updateProduct, o as checkManageKey, s as deleteProduct, u as updateShop } from "./router-DvrpmqTW.mjs";
import { r as clearCart, t as Shell } from "./shell-MUgdo7ZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/manage-DC52X-zK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "riwaq-manage-key";
function readManageKey() {
	if (typeof window === "undefined") return "";
	return sessionStorage.getItem(KEY) ?? "";
}
function writeManageKey(key) {
	sessionStorage.setItem(KEY, key);
}
function clearManageKey() {
	sessionStorage.removeItem(KEY);
}
var fieldClass = "min-h-11 w-full rounded-xl border border-line bg-surface px-3 text-ink outline-none";
function ManagePage() {
	const { shop, products } = Route$3.useLoaderData();
	const router = useRouter();
	const [key, setKey] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!shop.hasKey) {
			setReady(true);
			return;
		}
		const saved = readManageKey();
		if (!saved) {
			setReady(true);
			return;
		}
		let cancelled = false;
		checkManageKey({ data: { key: saved } }).then((result) => {
			if (cancelled) return;
			if (result.ok) setKey(saved);
			else clearManageKey();
			setReady(true);
		});
		return () => {
			cancelled = true;
		};
	}, [shop.hasKey]);
	function lock() {
		clearManageKey();
		setKey("");
		setError("");
	}
	function noteAuth(message) {
		if (message.includes("كلمة السر")) {
			clearManageKey();
			setKey("");
		}
		setError(message);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		shop,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-8 pt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary",
						children: "لوحة المحل"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl",
						children: "إدارة البضاعة"
					})] }), key ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: lock,
						className: "min-h-11 rounded-full px-3 text-sm text-muted",
						children: "اقفل الإدارة"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-muted",
					children: "المعرض عام: أي حدا يفتح الرابط يشوف نفس القطع. كلمة السر بس بتمنع التعديل، مش بتسكر المشاهدة. احفظها، ما في استرجاع من غير ما نضيف تسجيل دخول."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary",
					children: error
				}) : null,
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-muted",
					children: "عم نفتح اللوحة…"
				}) : !shop.hasKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Setup, {
					onDone: async (next) => {
						writeManageKey(next);
						setKey(next);
						setError("");
						await router.invalidate();
					},
					onError: setError
				}) : !key ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unlock, {
					onDone: (next) => {
						writeManageKey(next);
						setKey(next);
						setError("");
					},
					onError: setError
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					shop,
					products,
					manageKey: key,
					onError: noteAuth,
					onSaved: () => {
						setError("");
						return router.invalidate();
					}
				})
			]
		})
	});
}
function Setup({ onDone, onError }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setPending(true);
		const result = await setManageKey({ data: { key } });
		setPending(false);
		if (!result.ok) {
			onError(result.error);
			return;
		}
		await onDone(key.trim());
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => void submit(event),
		className: "mt-10 max-w-md space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "حط كلمة سر للمحل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "أول ما تنحط، ما حدا غيرك بيقدر يضيف أو يعدّل أو يحذف."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-sm text-muted",
				htmlFor: "new-key",
				children: "كلمة السر"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "new-key",
				type: "password",
				autoComplete: "new-password",
				value: key,
				minLength: 4,
				onChange: (event) => setKey(event.target.value),
				className: fieldClass,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: pending,
				className: "inline-flex min-h-11 items-center rounded-full bg-primary px-5 text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
				children: pending ? "عم نحفظ…" : "فعّل الإدارة"
			})
		]
	});
}
function Unlock({ onDone, onError }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setPending(true);
		const result = await checkManageKey({ data: { key } });
		setPending(false);
		if (!result.ok) {
			onError(result.error);
			return;
		}
		onDone(key.trim());
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => void submit(event),
		className: "mt-10 max-w-md space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "ادخل كلمة السر"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-sm text-muted",
				htmlFor: "key",
				children: "كلمة سر المحل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "key",
				type: "password",
				autoComplete: "current-password",
				value: key,
				onChange: (event) => setKey(event.target.value),
				className: fieldClass,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: pending,
				className: "inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-bg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
				children: pending ? "عم نتأكد…" : "افتح اللوحة"
			})
		]
	});
}
function Panel({ shop, products, manageKey, onError, onSaved }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10 grid gap-12 lg:grid-cols-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopForm, {
			shop,
			manageKey,
			onError,
			onSaved
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10 lg:col-span-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductEditor, {
				manageKey,
				currency: shop.currency,
				onError,
				onSaved
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductList, {
				products,
				currency: shop.currency,
				manageKey,
				onError,
				onSaved
			})]
		})]
	});
}
function ShopForm({ shop, manageKey, onError, onSaved }) {
	const [name, setName] = (0, import_react.useState)(shop.name);
	const [tagline, setTagline] = (0, import_react.useState)(shop.tagline);
	const [about, setAbout] = (0, import_react.useState)(shop.about);
	const [city, setCity] = (0, import_react.useState)(shop.city);
	const [whatsapp, setWhatsapp] = (0, import_react.useState)(shop.whatsapp);
	const [currency, setCurrency] = (0, import_react.useState)(shop.currency);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setName(shop.name);
		setTagline(shop.tagline);
		setAbout(shop.about);
		setCity(shop.city);
		setWhatsapp(shop.whatsapp);
		setCurrency(shop.currency);
	}, [shop]);
	async function submit(event) {
		event.preventDefault();
		setPending(true);
		setNote("");
		const result = await updateShop({ data: {
			key: manageKey,
			name,
			tagline,
			about,
			city,
			whatsapp,
			currency
		} });
		setPending(false);
		if (!result.ok) {
			onError(result.error);
			return;
		}
		if (currency !== shop.currency) clearCart();
		setNote("انحفظ تعريف المحل");
		await onSaved();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => void submit(event),
		className: "space-y-3 lg:col-span-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "تعريف المحل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الاسم",
				value: name,
				onChange: setName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "سطر تحت الاسم",
				value: tagline,
				onChange: setTagline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "نبذة",
				value: about,
				onChange: setAbout,
				multiline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "المدينة",
				value: city,
				onChange: setCity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "واتساب مع رمز البلد",
				value: whatsapp,
				onChange: setWhatsapp,
				placeholder: "9639xxxxxxx",
				inputMode: "tel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-muted",
				children: ["العملة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: currency,
					onChange: (event) => setCurrency(event.target.value),
					className: `${fieldClass} mt-1`,
					children: CURRENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.label
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: pending,
				className: "inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-bg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
				children: pending ? "عم نحفظ…" : "احفظ المحل"
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: note
			}) : null
		]
	});
}
function ProductEditor({ manageKey, currency, product, onError, onSaved, onCancel }) {
	const [title, setTitle] = (0, import_react.useState)(product?.title ?? "");
	const [summary, setSummary] = (0, import_react.useState)(product?.summary ?? "");
	const [story, setStory] = (0, import_react.useState)(product?.story ?? "");
	const [price, setPrice] = (0, import_react.useState)(product ? String(product.price) : "");
	const preset = CATEGORIES.some((item) => item.id === product?.category);
	const [category, setCategory] = (0, import_react.useState)(product ? preset ? product.category : "__custom" : "bags");
	const [customCategory, setCustomCategory] = (0, import_react.useState)(product && !preset ? product.category : "");
	const [origin, setOrigin] = (0, import_react.useState)(product?.origin ?? "");
	const [available, setAvailable] = (0, import_react.useState)(product?.available ?? true);
	const [featured, setFeatured] = (0, import_react.useState)(product?.featured ?? false);
	const [imageData, setImageData] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	async function onFile(file) {
		if (!file) {
			setImageData("");
			return;
		}
		try {
			setImageData(await compressImage(file));
			setNote("");
		} catch (error) {
			setImageData("");
			onError(error instanceof Error ? error.message : "الصورة ما انفتحت");
		}
	}
	async function submit(event) {
		event.preventDefault();
		const amount = Number(price);
		if (!Number.isInteger(amount)) {
			onError("السعر لازم يكون رقم صحيح، من غير فاصلة");
			return;
		}
		const chosen = category === "__custom" ? customCategory.trim() : category;
		setPending(true);
		setNote("");
		const result = await updateProduct({ data: {
			key: manageKey,
			id: product?.id,
			title,
			summary,
			story,
			price: amount,
			category: chosen,
			origin,
			available,
			featured,
			imageData
		} });
		setPending(false);
		if (!result.ok) {
			onError(result.error);
			return;
		}
		setNote(product ? "انعدّلت القطعة" : "انضافت القطعة");
		if (!product) {
			setTitle("");
			setSummary("");
			setStory("");
			setPrice("");
			setOrigin("");
			setImageData("");
			setFeatured(false);
			setAvailable(true);
		}
		await onSaved();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => void submit(event),
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: product ? "تعديل القطعة" : "قطعة جديدة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الاسم",
				value: title,
				onChange: setTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "سطر قصير",
				value: summary,
				onChange: setSummary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "التفاصيل",
				value: story,
				onChange: setStory,
				multiline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `السعر (${currency})`,
				value: price,
				onChange: setPrice,
				inputMode: "numeric"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-muted",
				children: ["التصنيف", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: category,
					onChange: (event) => setCategory(event.target.value),
					className: `${fieldClass} mt-1`,
					children: [CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.label
					}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "__custom",
						children: "تصنيف ثاني"
					})]
				})]
			}),
			category === "__custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "اسم التصنيف",
				value: customCategory,
				onChange: setCustomCategory
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "المصدر",
				value: origin,
				onChange: setOrigin
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: available,
					onChange: (event) => setAvailable(event.target.checked)
				}), "متوفرة على الرف"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: featured,
					onChange: (event) => setFeatured(event.target.checked)
				}), "تبيّن بأول المعرض"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-muted",
				children: [product ? "صورة جديدة (اختياري)" : "صورة القطعة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/*",
					required: !product,
					onChange: (event) => void onFile(event.target.files?.[0]),
					className: "mt-1 block w-full text-sm"
				})]
			}),
			imageData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: imageData,
				alt: "",
				className: "aspect-product w-32 rounded-xl object-cover"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: pending,
					className: "inline-flex min-h-11 items-center rounded-full bg-primary px-5 text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
					children: pending ? "عم نحفظ…" : product ? "احفظ التعديل" : "أضف للرف"
				}), onCancel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "min-h-11 rounded-full px-4 text-sm",
					children: "إلغاء"
				}) : null]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: note
			}) : null
		]
	});
}
function ProductList({ products, currency, manageKey, onError, onSaved }) {
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	async function remove(id) {
		const result = await deleteProduct({ data: {
			id,
			key: manageKey
		} });
		if (!result.ok) {
			onError(result.error);
			return;
		}
		setConfirmId(null);
		setEditing(null);
		await onSaved();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-3xl",
		children: "الرف الحالي"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 divide-y divide-line",
		children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [product.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: product.image,
					alt: "",
					className: "aspect-product w-16 rounded-xl object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-product w-16 rounded-xl bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-tight",
							children: product.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								categoryLabel(product.category),
								" ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: formatPrice(product.price, currency)
								}),
								product.available ? "" : " · مخفية عن الزبون"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full border border-line px-4 text-sm",
								onClick: () => setEditing(editing === product.id ? null : product.id),
								children: editing === product.id ? "سكر التعديل" : "تعديل"
							}), confirmId === product.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full px-4 text-sm text-primary",
								onClick: () => void remove(product.id),
								children: "تأكيد الحذف"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full px-4 text-sm text-muted",
								onClick: () => setConfirmId(product.id),
								children: "حذف"
							})]
						})
					]
				})]
			}), editing === product.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 border-t border-line pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductEditor, {
					manageKey,
					currency,
					product,
					onError,
					onSaved,
					onCancel: () => setEditing(null)
				})
			}) : null]
		}, product.id))
	})] });
}
function Field({ label, value, onChange, multiline = false, placeholder, inputMode }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm text-muted",
		htmlFor: id,
		children: [label, multiline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			id,
			value,
			placeholder,
			onChange: (event) => onChange(event.target.value),
			rows: 4,
			className: `${fieldClass} mt-1 py-3`
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			value,
			placeholder,
			inputMode,
			onChange: (event) => onChange(event.target.value),
			className: `${fieldClass} mt-1`
		})]
	});
}
function compressImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			const scale = Math.min(1, 1200 / Math.max(image.width, image.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(image.width * scale));
			canvas.height = Math.max(1, Math.round(image.height * scale));
			const context = canvas.getContext("2d");
			if (!context) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("المتصفح ما قدر يقرأ الصورة"));
				return;
			}
			context.drawImage(image, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(url);
			let quality = .82;
			let data = canvas.toDataURL("image/jpeg", quality);
			while (data.length > 9e5 && quality > .5) {
				quality -= .1;
				data = canvas.toDataURL("image/jpeg", quality);
			}
			if (data.length > 11e5) {
				reject(/* @__PURE__ */ new Error("الصورة كبيرة. اختار صورة أصغر"));
				return;
			}
			resolve(data);
		};
		image.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("هالصورة ما انفتحت. جرّب JPG"));
		};
		image.src = url;
	});
}
//#endregion
export { ManagePage as component };
