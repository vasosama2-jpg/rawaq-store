//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BcdB7JnM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/manage",
			"/media/$productId",
			"/product/$productId",
			"/section/$category"
		],
		preloads: ["/assets/index-V57ZbSOR.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-V57ZbSOR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C9u9h5sg.js", "/assets/shell-BQpiMSed.js"]
	},
	"/manage": {
		filePath: "/workspace/src/routes/manage.tsx",
		children: void 0,
		preloads: ["/assets/manage-uIGGA1TW.js", "/assets/shell-BQpiMSed.js"]
	},
	"/product/$productId": {
		filePath: "/workspace/src/routes/product/$productId.tsx",
		children: void 0,
		preloads: [
			"/assets/_productId-Dkbq-V32.js",
			"/assets/shell-BQpiMSed.js",
			"/assets/product-card-ZnhIB_5N.js"
		]
	},
	"/section/$category": {
		filePath: "/workspace/src/routes/section/$category.tsx",
		children: void 0,
		preloads: [
			"/assets/_category-DWv9DlaB.js",
			"/assets/shell-BQpiMSed.js",
			"/assets/product-card-ZnhIB_5N.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
