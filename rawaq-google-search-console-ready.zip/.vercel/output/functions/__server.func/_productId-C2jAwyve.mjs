import { o as __toESM } from "./_runtime.mjs";
import { a as formatPrice, i as categoryLabel, o as orderMessage, s as whatsappLink } from "./_ssr/shop-DYw5t3xI.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./_ssr/router-DvrpmqTW.mjs";
import { i as useCart, n as addToCart, t as Shell } from "./_ssr/shell-MUgdo7ZH.mjs";
import { t as ProductCard } from "./_ssr/product-card-Bvz8C15l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_productId-C2jAwyve.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { shop, product, related } = Route$1.useLoaderData();
	const inCart = useCart().find((line) => line.id === product.id);
	const [added, setAdded] = (0, import_react.useState)(false);
	const [broken, setBroken] = (0, import_react.useState)(false);
	const ask = whatsappLink(shop.whatsapp, orderMessage(shop.name, shop.currency, [{
		title: product.title,
		qty: 1,
		price: product.price
	}]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		shop,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-8 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "underline-offset-4 hover:underline",
							children: "الأقسام"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: " / "
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/section/$category",
							params: { category: product.category },
							className: "underline-offset-4 hover:underline",
							children: categoryLabel(product.category)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid items-start gap-8 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-2xl bg-surface",
						children: product.image && !broken ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: product.image,
							alt: product.title,
							className: "aspect-product w-full object-cover",
							onError: () => setBroken(true)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex aspect-product items-center justify-center font-display text-6xl text-muted",
							children: product.title.slice(0, 1)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl",
							children: product.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg",
							children: product.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-4xl tabular-nums text-primary",
							children: formatPrice(product.price, shop.currency)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								categoryLabel(product.category),
								product.origin ? ` · ${product.origin}` : "",
								product.available ? "" : " · خلصت من الرف"
							]
						}),
						product.story ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl whitespace-pre-line leading-relaxed text-ink",
							children: product.story
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: !product.available,
								onClick: () => {
									addToCart({
										id: product.id,
										title: product.title,
										price: product.price,
										image: product.image
									});
									setAdded(true);
								},
								className: "inline-flex min-h-11 items-center justify-center rounded-full bg-primary px-5 text-primary-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
								children: !product.available ? "غير متوفرة" : added || inCart ? `بالطلب${inCart ? ` · ${inCart.qty}` : ""}` : "أضف للطلب"
							}), ask ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: ask,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex min-h-11 items-center justify-center rounded-full border border-line bg-surface px-5 transition-transform duration-150 ease-out active:scale-[0.96]",
								children: "اسأل عنها على واتساب"
							}) : null]
						})
					] })]
				}),
				related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "كمان على الرف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-3",
						children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
							product: item,
							currency: shop.currency
						}) }, item.id))
					})]
				}) : null
			]
		})
	});
}
//#endregion
export { ProductPage as component };
